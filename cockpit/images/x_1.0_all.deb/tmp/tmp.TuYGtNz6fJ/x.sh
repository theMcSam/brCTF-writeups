exec /bin/sh
